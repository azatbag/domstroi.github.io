<?
$db_host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "domStroi";
$connect = new mysqli($db_host, $db_user, $db_password, $db_name);
function enteringUser($login){
	global $connect;
	$query = mysqli_fetch_array($connect->query("SELECT * FROM `users` WHERE `login` = '$login'"));
	$_SESSION['login'] = $login;
	$_SESSION['userId'] = $query['id'];
	$_SESSION['role'] = $query['role'];
	header('location: http://domStroi');
}