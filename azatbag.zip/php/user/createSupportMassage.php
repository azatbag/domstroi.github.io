<?
if (isset($_POST['phone'])){
	require_once("../dbconnect.php");
	$request = $connect->query("SELECT * FROM `requests` WHERE `name` = '".$_POST['name']."' 
	AND `phone` = '".$_POST['phone']."' AND `idAdvert` = '".$_POST['idAdvert']."' AND `status` = 'work'");
	if (($request->num_rows) > 0){
		echo "Вы уже подали заявку на консультацию";
		die();
	}
	$connect->query("INSERT INTO `requests` (`name`, `phone`, `idAdvert`) VALUES ('".$_POST['name']."','".$_POST['phone']."','".$_POST['idAdvert']."')");
	echo "Заявка на консультацию создана";
}