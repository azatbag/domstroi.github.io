<?
if (isset($_GET['type']) || isset($_GET['capacity']) || isset($_GET['price'])){
    require_once('../dbconnect.php');
    $type = $_GET['type'];
    $capacity = $_GET['capacity'];
    if ($type != '*' AND $type == 'office'){
        $capacity = 0;
    }
    switch ($_GET['price']) {
        case '1':{
            $minPrice = 0; 
            $maxPrice = 500000;
            break;
        }
        case '2':{
            $minPrice = 500000; 
            $maxPrice = 1000000;
            break;
        }
        case '3':{
            $minPrice = 1000000; 
            $maxPrice = 2500000;
            break;
        }
        case '4':{
            $minPrice = 2500000; 
            $maxPrice = 99999999;
            break;
        }
        default:{
            $minPrice = 0; 
            $maxPrice = 99999999;
        }
    }
    $adverts = $connect->query("SELECT * FROM `adverts` WHERE `type` LIKE '$type' AND `capacity` LIKE '$capacity' AND `price` >= '$minPrice' AND `price` <= '$maxPrice'");
    while ($row = $adverts->fetch_assoc()){
        $picture = $connect->query("SELECT `url` FROM `pictures` WHERE `idAdvert` = '".$row['id']."' ORDER BY `id` LIMIT 1")->fetch_assoc();
        if ($row['type'] == 'new') $type = 'Новая квартира';
        else if ($row['type'] == 'second') $type = 'Вторичный рынок';
        else $type = 'Офис';
        echo "<a class='advert' href='advert.php?id=", $row['id'],"'>
        <div id='picture' style='background-image: url(image/",$picture['url'],".jpg)'></div>
        <div>", $row['name'],"</div>
        <div>", $row['price'],"₽</div>
        <div>", $row['address'],"</div>
        <div>", $type,"</div></a>";
    }
}
else{
	echo "<script>alert('Не знаю, как вы сюда попали')</script>";
	header("Refresh:0, url = 'http://domstroi'");
	die();
}