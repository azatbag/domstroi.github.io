<?
require_once('dbconnect.php');
session_start();
if (isset($_POST['login']) && isset($_POST['password'])){
	$login = $_POST['login'];
	$password = $_POST['password'];
	$query = $connect->query("SELECT * FROM `users` WHERE `login` = '$login' AND `password` = '$password'");
	if (mysqli_num_rows($query) > 0){
		enteringUser($login);
	}
	else{
		echo "<script>alert('Вы ввели неверные данные')</script>";
		header("Refresh:0, url = 'http://domstroi'");
		die();
	}
}
else{
	echo "<script>alert('Вы ввели неверные данные')</script>";
	header("Refresh:0, url = 'http://domstroi'");
	die();
}