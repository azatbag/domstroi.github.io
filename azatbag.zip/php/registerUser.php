<?
require_once('dbconnect.php');
session_start();
if (isset($_POST['login']) && isset($_POST['password']) && isset($_POST['email'])){
	$login = $_POST['login'];
	$connect->query("INSERT INTO `users`(`login`, `password`, `name`, `phone`, `email`) VALUES 
	('$login','".$_POST['password']."','".$_POST['name']."','".$_POST['phone']."','".$_POST['email']."')");
    enteringUser($login);
}
else{
	echo "<script>alert('Не знаю, как вы сюда попали')</script>";
	header("Refresh:0, url = 'http://domstroi'");
	die();
}