<?
session_start();
if ($_SESSION['role'] == 'admin'){
    require_once('../dbconnect.php');
    if (count($_FILES['image']['tmp_name']) <= 5) $countPictures = count($_FILES['image']['tmp_name']);
    else  $countPictures = 5;
    for ($i = 0; $i < $countPictures; $i++){
        if($_FILES['image']['type'][$i] != "image/jpeg" && $_FILES['image']['type'][$i] != "image/png"){
            echo "<script>alert('Сервер принимает картинки только с разрешением .jpg или .png')</script>";
            header("Refresh:0, url = 'http://domstroi'");
            die();
        }
    }
    $connect->query("INSERT INTO `adverts`(`name`, `address`, `price`, `type`, `capacity`, `description`) VALUES ('none', 'none', 0, 'none', 0, 'none')");
    $idAdvert = ($connect->query("SELECT `id` FROM `adverts` WHERE `type` = 'none' AND `capacity` = 0"))->fetch_assoc();
    If ($_POST['type'] == 'office') $capacity = 0;
    else $capacity = $_POST['capacity'];
    $connect->query("UPDATE `adverts` SET `name`='".$_POST['name']."',`address`='".$_POST['address']."',`price`='".$_POST['price']."',`type`='".$_POST['type']."',`capacity`='$capacity',`description`='".$_POST['description']."' WHERE `id` = '".$idAdvert['id']."'");
    for ($i = 0; $i < $countPictures; $i++){
        move_uploaded_file($_FILES['image']['tmp_name'][$i], "../../image/".$idAdvert['id'].$i.".jpg");
        $connect->query("INSERT INTO `pictures`(`idAdvert`,`url`) VALUES ('".$idAdvert['id']."','".$idAdvert['id'].$i."')");
    }
    echo "<script>alert('Объявление создано')</script>";
    header("Refresh:0, url = 'http://domstroi'");
    die();
}
else{
    echo "<script>alert('Ы')</script>";
    header("Refresh:0, url = 'http://domstroi'");
    die();
}