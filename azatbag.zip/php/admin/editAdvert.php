<?
session_start();
if ($_SESSION['role'] == 'admin'){
    require_once('../dbconnect.php');
    $currentCountPictures = $connect->query("SELECT * FROM `pictures` WHERE `idAdvert` = '".$_POST['id']."'")->num_rows;
    echo count($_FILES['image']['tmp_name']);
    if (isset($_FILES['image']) && count($_FILES['image']['tmp_name']) < 5 - $currentCountPictures) $countPictures = count($_FILES['image']['tmp_name']);
    else  $countPictures = 5 - $currentCountPictures;
    for ($i = 0; $i < $countPictures; $i++){
        if($_FILES['image']['type'][$i] != "image/jpeg" && $_FILES['image']['type'][$i] != "image/png"){
            $countPictures--;
        }
    }
    If ($_POST['type'] == 'office') $capacity = 0;
    else $capacity = $_POST['capacity'];
    $connect->query("UPDATE `adverts` SET `name`='".$_POST['name']."',`address`='".$_POST['address']."',`price`='".$_POST['price']."',`type`='".$_POST['type']."',`capacity`='$capacity',`description`='".$_POST['description']."' WHERE `id` = '".$_POST['id']."'");
    for ($i = 0; $i < $countPictures; $i++){
        move_uploaded_file($_FILES['image']['tmp_name'][$i], "../../image/".$_POST['id'].$i.".jpg");
        $connect->query("INSERT INTO `pictures`(`idAdvert`,`url`) VALUES ('".$_POST['id']."','".$_POST['id'].$i."')");
    }
    echo "<script>alert('Объявление сохранено')</script>";
    header("Refresh:0, url = 'http://domstroi'");
    die();
}
else{
    echo "<script>alert('Ы')</script>";
    header("Refresh:0, url = 'http://domstroi'");
    die();
}