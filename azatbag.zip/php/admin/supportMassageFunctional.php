<?
session_start();
if ($_SESSION['role'] == 'admin'){
    require_once('../dbconnect.php');
    $_POST['type']($_POST['idRequest']);
}
function delete($idRequest){
    global $connect;
    $connect->query("DELETE FROM `requests` WHERE `id` = '$idRequest'");
}
function decided($idRequest){
    global $connect;
    $connect->query("UPDATE `requests` SET `status`='decided' WHERE `id` = '$idRequest'");
}