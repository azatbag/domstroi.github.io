<?
require_once("php/dbconnect.php");
$requests = $connect->query("SELECT * FROM `requests` WHERE `status` = 'work'");
echo "<div id='operationWindow' class='operationWindow hidden'></div>
<div class='adminUiWindow'><div class='supportMassagesWindow'><div>Заявок в тех. поддержку";
if (($requests->num_rows) > 0) echo ": ".$requests->num_rows;
else echo " нет";
echo "</div><div><div>Имя</div><div>Телефон</div><div>Id объявления</div></div>";
while ($row = $requests->fetch_assoc()){
    echo "<div><div id='request", $row['id'],"' class='supportMassage' onclick='operationWindowManager($(this), ", $row['id'],")'>
    <div>", $row['name'],"</div>
    <div>", $row['phone'],"</div>
    <div>", $row['idAdvert'],"</div></div></div>";
}
echo "</div><a class='btn acceptBtn' href='createAdvert.php'>Создать новое объявление</a></div>
<div class='mainUiWindow'><div><div class='searchWindow'>
<div>Тип недвижимости</div>
<select id='type'>
    <option value='%' selected>Любой</option>
    <option value='new'>Новая квартира</option>
    <option value='second'>Вторичный рынок</option>
    <option value='office'>Офис</option>
</select>
<div>Число комнат</div>
<select id='capacity'>
    <option value='%' selected>Любое</option>
    <option value='1'>1-комнатная</option>
    <option value='2'>2-комнатная</option>
    <option value='3'>3-комнатная</option>
    <option value='4'>4-комнатная</option>
</select>
<div>Стоимость</div>
<select id='price'>
    <option value='%' selected>Любая</option>
    <option value='1'>0 - 500000</option>
    <option value='2'>500000 - 1000000</option>
    <option value='3'>1000000 - 2500000</option>
    <option value='4'>Более 2500000</option>
</select>
<div class='btn acceptBtn' onclick='searchAdvert()'>Поиск</div>
</div></div><div class='advertsWindow'>";
$query = $connect->query("SELECT * FROM `adverts`");
while($row = $query->fetch_assoc()){
    $picture = $connect->query("SELECT `url` FROM `pictures` WHERE `idAdvert` = '".$row['id']."' ORDER BY `id` LIMIT 1")->fetch_assoc();
    if ($row['type'] == 'new') $type = 'Новая квартира';
    else if ($row['type'] == 'second') $type = 'Вторичный рынок';
    else $type = 'Офис';
    echo "<a class='advert' href='advert.php?id=", $row['id'],"'>
    <div id='picture' style='background-image: url(image/",$picture['url'],".jpg)'></div>
    <div>", $row['name'],"</div>
    <div>", $row['price'],"₽</div>
    <div>", $row['address'],"</div>
    <div>", $type,"</div></a>";
}
echo "<div></div></div>";