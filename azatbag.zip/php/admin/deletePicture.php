<?
session_start();
if ($_SESSION['role'] == 'admin'){
    require_once('../dbconnect.php');
    $connect->query("DELETE FROM `pictures` WHERE `id` = '".$_GET['idPicture']."'");
}
else{
    echo "<script>alert('Ы')</script>";
    header("Refresh:0, url = 'http://domstroi'");
    die();
}