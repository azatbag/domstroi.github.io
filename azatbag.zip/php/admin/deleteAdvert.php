<?
session_start();
if ($_SESSION['role'] == 'admin'){
    require_once('../dbconnect.php');
    $connect->query("DELETE FROM `adverts` WHERE `id` = '".$_GET['idAdvert']."'");
    echo 'Объявление удалено';
}