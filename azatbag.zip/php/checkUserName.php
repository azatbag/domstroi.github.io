<?
if (isset($_POST['userName'])){
    require_once('dbconnect.php');
    $userName = $_POST['userName'];
    $query = $connect->query("SELECT * FROM `users` WHERE `login` = '$userName'");
    if (mysqli_num_rows($query) > 0){
        echo 'error';
    }
    else{
        echo 'success';
    }
}
else if (isset($_POST['email'])){
    require_once('dbconnect.php');
    $email = $_POST['email'];
    $query = $connect->query("SELECT * FROM `users` WHERE `email` = '$email'");
    if (mysqli_num_rows($query) > 0){
        echo 'error';
    }
    else{
        echo 'success';
    }
}