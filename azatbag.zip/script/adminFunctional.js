var operationWindow = $('#operationWindow'),
    operationWindowOpened = false,
    animationRunning = false;
function operationWindowManager(operationWindowBtn, requestId) {
    if (operationWindowOpened && animationRunning == false) {
        operationWindow.css('animation', 'closeOperationWindow .5s ease forwards');
        operationWindowOpened = false;
        animationRunning = true;
        freeze = setTimeout(function() {
            operationWindow.addClass('hidden')
            animationRunning = false;
        }, 500);
    } else if (animationRunning == false) {
        operationWindow.css('width', operationWindowBtn.css('width'));
        operationWindow.css('top', operationWindowBtn.offset().top + 50 + 'px');
        operationWindow.css('left', operationWindowBtn.offset().left - 1 + 'px');
        operationWindow.html('<div class="btn acceptBtn" onclick="requestOperation(' + requestId + ',' + "'decided'" + ')">Решена</div>\
            <div class="btn cancleBtn" onclick="requestOperation(' + requestId + ',' + "'delete'" + ')">Удалить</div>');
        operationWindow.removeClass('hidden');
        operationWindow.css('animation', 'openOperationWindow .5s ease forwards');
        operationWindowOpened = true;
        animationRunning = true;
        freeze = setTimeout(function() {
            animationRunning = false;
        }, 500);
    }
}
function requestOperation(idRequest, type){
    $.post('../php/admin/supportMassageFunctional.php', {idRequest: idRequest, type: type}, 
        function(data){
            $('#request' + idRequest).remove();
            operationWindowManager('h');
        })
}