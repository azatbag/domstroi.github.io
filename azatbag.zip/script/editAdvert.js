function setInfo(type, capacity){
	$('#' + type).prop('checked', 'true');
	switch(capacity){
		case 0: capacityBtns.prop('disabled', true); break;
		case 1: $('#one-room').prop('checked', 'true'); break;
		case 2: $('#two-room').prop('checked', 'true'); break;
		case 3: $('#three-room').prop('checked', 'true'); break;
		case 4: $('#four-room').prop('checked', 'true'); break;
	}
}
function deletePicture(idPicture){
	var deleteConfirm = confirm("Удалить изображение?");
	if (deleteConfirm){
		$.get('../php/admin/deletePicture.php', {idPicture: idPicture}, function(data){
			$('#picture' + idPicture).remove();
		})
	}
}