var heightWindow = window.innerHeight - 20;
document.getElementById("mainWindow").style.height = heightWindow + "px";