var capacityBtns = $('input[name=capacity'),
price = $('input[name=price');

price.change(function(){
	if (price.is(':invalid')) price.css('border-bottom', '2px solid red');
    else price.css('border-bottom', '2px solid green');
});
$('input[name="type"]').change(function(){
	if ($('#office').is(':checked')){
		capacityBtns.prop('disabled', true);
		capacityBtns.prop('checked', false);
	}
	else{
		capacityBtns.prop('disabled', false);
	}
})