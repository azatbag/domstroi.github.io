var phone = $('input[name=phone]'),
    pictureWindow = $('#pictureWindow'),
    supportWindow = $('#supportWindow'),
    supportWindowOpened = false,
    animationRunning = false;

phone.change(function(){
    if (phone.is(':invalid')) phone.css('border-bottom', '2px solid red');
    else phone.css('border-bottom', '2px solid green');
});
function swicthPic(selectPic) {
    if (animationRunning == false){
        pictureWindow.children('#selectedPic').css('background-image', selectPic.css('background-image'));
        selectPic.parent().children('.selectedPic').removeClass('selectedPic');
        selectPic.addClass('selectedPic');
        animationRunning = true;
        freeze = setTimeout(function(){animationRunning = false},500);
    }
}

function supportWindowManager(supportWindowBtn) {
    if (supportWindowOpened && animationRunning == false) {
        supportWindow.css('animation', 'closeSupportWindow .5s ease forwards');
        supportWindowOpened = false;
        animationRunning = true;
        freeze = setTimeout(function() {
            supportWindow.addClass('hidden')
            animationRunning = false;
        }, 500);
    } else if (animationRunning == false) {
        supportWindow.css('width', supportWindowBtn.css('width'));
        supportWindow.css('top', supportWindowBtn.offset().top + 50 + 'px');
        supportWindow.css('left', supportWindowBtn.offset().left - 1 + 'px');
        supportWindow.removeClass('hidden');
        supportWindow.css('animation', 'openSupportWindow .5s ease forwards');
        supportWindowOpened = true;
        animationRunning = true;
        freeze = setTimeout(function() {
            animationRunning = false;
        }, 500);
    }
}
function createSupportMassage(idAdvert){
    $.post('../php/user/createSupportMassage.php', {name: $('#name').val(), phone: $('#phone').val(), idAdvert: idAdvert}, 
        function(data){
            alert(data);
            supportWindowManager('h');
        })
}
function deleteAdvert(idAdvert){
    $.get('../php/admin/deleteAdvert.php', {idAdvert: idAdvert}, function(data){
        alert(data);
        window.location.href='http://domstroi';
    })
}