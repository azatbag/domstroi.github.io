var enterBtn = $('#enterBtn'),
login = $('input[name=login]'),
phone = $('input[name=phone]'),
email = $('input[name=email]'),
passwordWields = $('input[type=password]'),
password = $('input[name=password]'),
confirmPassword = $('input[name=confirmPassword]');

var enableLogin = false, enableEmail = false, enablePassword = false;

login.change(function(){
    $.post('../php/checkUserName.php', {userName: login.val()}, function(data){
        if (data == 'success'){
            login.css('border-bottom', '2px solid green');
            enableLogin = true;
            checkData();
        }
        else{
            login.css('border-bottom', '2px solid red');
            enableLogin = false;
            enterBtn.prop('disabled', true);
            console.log(data);
        } 
    })
});
phone.change(function(){
    if (phone.is(':invalid')) phone.css('border-bottom', '2px solid red');
    else phone.css('border-bottom', '2px solid green');
});
email.change(function(){
    $.post('../php/checkUserName.php', {email: email.val()}, function(data){
        if (data == 'success' && email.is(':valid')){
            email.css('border-bottom', '2px solid green');
            enableEmail = true;
            checkData();
        }
        else{
            email.css('border-bottom', '2px solid red');
            enableEmail = false;
            enterBtn.prop('disabled', true);
        } 
    })
});
passwordWields.change(function(){
    if (confirmPassword.val() == password.val()){
        confirmPassword.css('border-bottom', '2px solid green');
        enablePassword = true;
        checkData();
    }
    else{
        confirmPassword.css('border-bottom', '2px solid red');
        enablePassword = false;
        enterBtn.prop('disabled', true);
    }
});
function checkData(){
    if (enableLogin && enableEmail && enablePassword) enterBtn.prop('disabled', false);
}