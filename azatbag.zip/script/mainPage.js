function searchAdvert(){
    $.get('../php/user/searchAdverts.php', {type: $('#type').val(),
        capacity: $('#capacity').val(),
        price: $('#price').val()}, 
        function(data){
            $('.advertsWindow').html(data);
        })
}